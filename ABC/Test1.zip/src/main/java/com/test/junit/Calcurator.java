package com.test.junit;

public class Calcurator {
    public double sum(double a, double b){
        return a + b;
    }
}