package com.test.junit;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Test;

public class CalcuratorTest {

	@Test
	public void testSum() {
		fail("Not yet implemented");
	}

}
